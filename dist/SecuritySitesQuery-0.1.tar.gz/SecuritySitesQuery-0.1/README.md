# SecuritySitesQuery

一个用来搜索安全相关网站的命令行小工具，可以查询IP地址、域名、SSL证书

查询结果可以选择直接显示、导出为json或excel表格

支持同时查询以下四个网站：

https://www.shodan.io

https://www.malwaredomainlist.com

https://sslbl.abuse.ch

https://zeustracker.abuse.ch/blocklist.php

其中前两个网站为在线查询，后两个会在查询前将数据更新到本地后查询

## 使用

程序在 Python 3 下执行， 需要先安装好 setuptools

第三方依赖包: shodan, sqlalchemy, click, xlsxwriter

```bash
# 安装
python3 setup.py install
# 搜索全部四个网站，将结果导出为json和excel
ssq seu.edu.cn
# 不更新, 仅搜索ZeusTracker, 仅导出json
ssq bright.su 4 -u 0 -o 1
# 指定关键词为IP，仅搜索Shodan和MDL，仅导出xlsx表格
ssq 104.27.163.228 1 2 -m 1 -o 2
# 仅搜索SSLBL, 导出json和excel到/home/xxx, 文件名为output
ssq izqertuiwt.biz 3 -p ~ -n output
# 搜索证书的sha1码, 输出结果到控制台
ssq e0d903bbddc642e5f7820b22d86eae9e15a7b2f8 -o 3
```

## 最近更新时间

 - Update 20180815 : 初步完成，版本0.1



