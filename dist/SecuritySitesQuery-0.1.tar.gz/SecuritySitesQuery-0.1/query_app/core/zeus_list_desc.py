ZEUS_DESCRIPTION = [
'''If you want to block domain names used by the ZeuS trojan, you should use this list. 
The ZeuS domain blocklist (BadDomains) is the recommended blocklist if you want to block only ZeuS domain names. 
It excludes domain names that ZeuS Tracker believes to be hijacked (level 2). 
Hence the false positive rate should be much lower compared to the standard ZeuS domain blocklist (see below).''',
'''This blocklists only includes IPv4 addresses that are used by the ZeuS trojan. 
It is the recommened blocklist if you want to block only ZeuS IPs. 
It excludes IP addresses that ZeuS Tracker believes to be hijacked (level 2) or belong to a free web hosting provider (level 3). 
Hence the false postive rate should be much lower compared to the standard ZeuS IP blocklist (see below).''',
'''This blocklist contains the same data as the ZeuS domain blocklist (BadDomains) but with the slight difference that it doesn't exclude hijacked websites (level 2). 
This means that this blocklist contains all domain names associated with ZeuS C&Cs which are currently being tracked by ZeuS Tracker. 
Hence this blocklist will likely cause some false positives.''',
'''This blocklist contains the same data as the ZeuS IP blocklist (BadIPs) but with the slight difference that it doesn't exclude hijacked websites (level 2) and free web hosting providers (level 3). 
This means that this blocklist contains all IPv4 addresses associated with ZeuS C&Cswhich are currently being tracked by ZeuS Tracker. 
Hence this blocklist will likely cause some false positives.''',
'''This blocklist only contains compromised / hijacked websites (level 2) which are being abused by cybercriminals to host a ZeuS botnet controller. 
Since blocking the FQDN or IP address of compromised host would cause a lot of false positives, the ZeuS compromised URL blocklist contains the full URL to the ZeuS config, dropzone or malware binary instead of the FQDN / IP address.'''
]
